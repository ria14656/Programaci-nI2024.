﻿namespace TuProyecto
{
    public class ContentPage
    {
    }
}